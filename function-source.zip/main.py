import base64
import functions_framework
from google.cloud import firestore
from datetime import datetime
import pytz

# Initialize Firestore client
db = firestore.Client()

@functions_framework.cloud_event
def hello_pubsub(cloud_event):
    # Decode the Pub/Sub message
    message = base64.b64decode(cloud_event.data["message"]["data"]).decode("utf-8")

    try:
        # Parse the message
        patient_id, time_string, spo2_str, bpm_str = message.split(', ')
        spo2 = int(spo2_str.split(': ')[1])
        bpm = int(bpm_str.split(': ')[1])

        # Convert the time string to UTC datetime
        naive_time = datetime.strptime(time_string, '%Y-%m-%d %H:%M:%S')
        # Adjust for timezone (UTC-6 in this example)
        tz = pytz.timezone('Etc/GMT+6')
        localized_time = tz.localize(naive_time)
        utc_time = localized_time.astimezone(pytz.utc)

        # Prepare the document to insert
        doc_data = {
            'patientid': patient_id,
            'controltime': utc_time,  # Use the UTC datetime directly
            'bpm': bpm,
            'spo2': spo2
        }

        # Add a new document with a generated ID to the 'heartrate' collection
        db.collection('heartrate').add(doc_data)

    except ValueError as e:
        print(f"Error processing message: {message}\n{e}")

    # Optional: Print the data to the logs
    print("Processed message:", message)
